package com.biblioteca.multa_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MultaServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MultaServiceApplication.class, args);
	}

}
