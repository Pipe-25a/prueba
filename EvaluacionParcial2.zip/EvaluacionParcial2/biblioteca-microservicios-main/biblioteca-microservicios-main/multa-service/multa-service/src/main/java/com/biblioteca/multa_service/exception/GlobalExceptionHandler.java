package com.biblioteca.multa_service.exception;
import java.time.LocalDateTime;
import java.util.List;
import java.util.NoSuchElementException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import com.biblioteca.multa_service.dto.ApiErrorResponse;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
/**
 * GlobalExceptionHandler es una clase que maneja las excepciones de manera
 * global en la aplicación. Utiliza la anotación @RestControllerAdvice para
 * indicar que es un controlador de excepciones y la anotación @Slf4j para
 * habilitar el registro de logs. Esta clase define varios métodos que manejan
 * diferentes tipos de excepciones, como DataIntegrityViolationException,
 * NoSuchElementException, MethodArgumentNotValidException y RuntimeException.
 * Cada método crea una respuesta de error estructurada utilizando la clase
 * ApiErrorResponse, que incluye información sobre el error, como el timestamp,
 * el status, el error, el mensaje y el path de la solicitud. Luego, devuelve
 * una respuesta HTTP con el estado correspondiente y el cuerpo de la respuesta
 * de error. Además, cada método registra el error en los logs para facilitar la
 * depuración. Esta clase ayuda a centralizar el manejo de excepciones en la
 * aplicación y a proporcionar respuestas de error consistentes y estructuradas
 * a los clientes.
 */
@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {
    /**
     * Captura y maneja excepciones de tipo DataIntegrityViolationException.
     * Esta excepción ocurre cuando se viola una restricción de integridad
     * en la base de datos. 
     * Generalmente sucede en situaciones como:
     * - Intentar insertar datos duplicados.
     * - Eliminar un registro que está relacionado con otros registros.
     * - Guardar valores inválidos en columnas restringidas.
     * - Violaciones de claves primarias o foráneas.
     */
    @ExceptionHandler(DataIntegrityViolationException.class)
    public ResponseEntity<ApiErrorResponse> handleDataIntegrityViolationException(
            DataIntegrityViolationException ex,
            HttpServletRequest request) {
        log.error("Data integrity violation: {}", ex.getMessage());
        ApiErrorResponse errorResponse = ApiErrorResponse.builder()
                .timestamp(LocalDateTime.now())
                .status(HttpStatus.CONFLICT.value())
                .error(HttpStatus.CONFLICT.name())
                .message("Data integrity violation")
                .path(request.getRequestURI())
                .build();
        return ResponseEntity.status(HttpStatus.CONFLICT).body(errorResponse);
    }
    /**
     * Captura y maneja excepciones de tipo NoSuchElementException.
     * Esta excepción ocurre cuando la aplicación intenta buscar
     * un elemento en la base de datos y dicho elemento no existe.
     * Por ejemplo:
     * - Buscar una multa por un ID inexistente.
     * - Buscar un préstamo eliminado.
     * - Consultar un usuario que no está registrado.
     */
    @ExceptionHandler(NoSuchElementException.class)
    public ResponseEntity<ApiErrorResponse> handleNoSuchElementException(NoSuchElementException ex,
            HttpServletRequest request) {
        log.error("Entity not found: {}", ex.getMessage());
        ApiErrorResponse errorResponse = ApiErrorResponse.builder()
                .timestamp(LocalDateTime.now())
                .status(HttpStatus.NOT_FOUND.value())
                .error(HttpStatus.NOT_FOUND.name())
                .message(ex.getMessage())
                .path(request.getRequestURI())
                .build();
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponse);
    }
    /**
     * Captura y maneja excepciones de tipo MethodArgumentNotValidException.
     * Esta excepción ocurre cuando fallan las validaciones realizadas
     * sobre los datos enviados en una petición HTTP.
     * Generalmente sucede cuando se utilizan anotaciones como:
     * - @NotNull
     * - @NotBlank
     * - @Size
     * - @Email
     * - @Valid
     * sobre los DTOs de entrada y alguno de los campos no cumple
     * las reglas definidas.
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ApiErrorResponse> handleMethodArgumentNotValidException(
            MethodArgumentNotValidException ex,
            HttpServletRequest request) {
        log.error("Invalid request: {}", ex.getMessage());
        List<String> errors = ex.getBindingResult().getFieldErrors().stream()
                .map(e -> e.getField() + ": " + e.getDefaultMessage())
                .toList();
        ApiErrorResponse errorResponse = ApiErrorResponse.builder()
                .timestamp(LocalDateTime.now())
                .status(HttpStatus.BAD_REQUEST.value())
                .error(HttpStatus.BAD_REQUEST.name())
                .message("Invalid request")
                .path(request.getRequestURI())
                .errors(errors)
                .build();
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
    }
    /**
     * Captura y maneja excepciones de tipo IllegalStateException.
     * Este tipo de excepción ocurre cuando se intenta realizar una
     * operación que no es válida según el estado actual de la aplicación.
     * Por ejemplo:
     * - Intentar devolver un préstamo ya devuelto.
     * - Intentar generar una multa duplicada.
     * - Ejecutar una acción que viola reglas de negocio.
     */
    @ExceptionHandler(IllegalStateException.class)
    public ResponseEntity<ApiErrorResponse> handleIllegalStateException(IllegalStateException ex,
            HttpServletRequest request) {
        log.error("Illegal state: {}", ex.getMessage());
        ApiErrorResponse errorResponse = ApiErrorResponse.builder()
                .timestamp(LocalDateTime.now())
                .status(HttpStatus.CONFLICT.value())
                .error(HttpStatus.CONFLICT.name())
                .message(ex.getMessage())
                .path(request.getRequestURI())
                .build();
        return ResponseEntity.status(HttpStatus.CONFLICT).body(errorResponse);
    }
    /**
     * Captura y maneja todas las excepciones de tipo RuntimeException
     * que puedan ocurrir en la aplicación.
     * 
     * Este método se ejecuta automáticamente cuando se produce un error
     * inesperado durante una petición HTTP y no existe otro manejador
     * específico para la excepción.
     */
    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<ApiErrorResponse> handleRuntimeException(RuntimeException ex,
            HttpServletRequest request) {
        log.error("Unexpected error: {}", ex.getMessage());
        ApiErrorResponse errorResponse = ApiErrorResponse.builder()
                .timestamp(LocalDateTime.now())
                .status(HttpStatus.INTERNAL_SERVER_ERROR.value())
                .error(HttpStatus.INTERNAL_SERVER_ERROR.name())
                .message("Unexpected error")
                .path(request.getRequestURI())
                .build();
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
    }
}